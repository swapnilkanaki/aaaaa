package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.View.OnClickListener;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.view.*;
import android.widget.TextView;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity implements OnClickListener,OnCheckedChangeListener
{
	private ToggleButton t1;
	private Switch s;
	private LinearLayout l;
	
	private CheckBox ch1,ch2,ch3;
	private RadioButton r1,r2;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		t1=(ToggleButton)findViewById(R.id.toggal1);
		s=(Switch)findViewById(R.id.mainSwitch);
		s.setOnCheckedChangeListener(this);
		t1.setOnClickListener(this);
		l=(LinearLayout)findViewById(R.id.mainLinearLayout);
		
		ch1=(CheckBox)findViewById(R.id.mainCheckBox1);
		ch2=(CheckBox)findViewById(R.id.mainCheckBox2);
		ch3=(CheckBox)findViewById(R.id.mainCheckBox3);
		r1=(RadioButton)findViewById(R.id.mainRadioButton1);
		r2=(RadioButton)findViewById(R.id.mainRadioButton2);
		r1.setOnCheckedChangeListener(this);
		r2.setOnCheckedChangeListener(this);
		
    }

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		ToggleButton b=(ToggleButton)arg0;
		if(b.isChecked())
		{
			l.setGravity(Gravity.CENTER_HORIZONTAL);
			l.setBackgroundColor(Color.DKGRAY);
			}
		else{
			l.setGravity(Gravity.CENTER_VERTICAL);
			l.setBackgroundColor(Color.CYAN);
			}

	}
	

	@Override
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		// TODO: Implement this method
		/*if(p2)
		{
			l.setBackgroundColor(Color.GREEN);
			l.setOrientation(1);
		}
		else
		{
			l.setOrientation(0);
			l.setBackgroundColor(Color.BLUE);
		}*/
		//Toast.makeText(this," clicke = "+p1+" boolean = "+p2,Toast.LENGTH_SHORT).show();
		
		if(p1.getId()==R.id.mainRadioButton1){
			Toast t= Toast.makeText(this," windows = "+ch1.isChecked()+  " linux = "+ch2.isChecked()+  " ubuntu = "+ch3.isChecked(),Toast.LENGTH_SHORT);
			t.setGravity(0,0,Gravity.TOP);
			t.show();
			
			}
		else{
			ch1.setChecked(false);
			ch2.setChecked(false);
			ch3.setChecked(false);
		}
	}

	public void customtoast(View v){
		LayoutInflater lf=getLayoutInflater();
		View ctv=lf.inflate(R.layout.ctoast,(ViewGroup)findViewById(R.id.ctoastLinearLayout));
		TextView tv=(TextView)ctv.findViewById(R.id.ctoastTextView1);
		Toast t=new Toast(this);
		tv.setText("a=");
		t.setView(ctv);
		t.show();
	}

	
}
